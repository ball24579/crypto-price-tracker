from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

COINGECKO_API_URL = "https://api.coingecko.com/api/v3/simple/price?ids=all&vs_currencies=usd,thb"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/prices')
def get_prices():
    try:
        response = requests.get(COINGECKO_API_URL)
        data = response.json()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
